package com.fasterxml.jackson.annotation;

import junit.framework.TestCase;

public abstract class TestBase extends TestCase
{
}
